

<?php $__env->startSection('content'); ?>
    <div class="main-container">
        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="page-header">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="title">
                                <h4>Detail Laporan Kas
                                </h4>
                            </div>
                            <nav aria-label="breadcrumb" role="navigation">
                            </nav>
                        </div>
                    </div>
                </div>

                <div class="pd-20 bg-white border-radius-4 box-shadow mb-30">
                    <?php
                        date_default_timezone_set('Asia/Jakarta');
                        $tgl = date('m');
                    ?>
                    <form action="<?php echo e(route('cari_bulan')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row float-center">

                            <select class="form-control" name="periode" aria-label="Default select example">
                                <?php
                                    $bulan = ['Januari' => '1', 'Februari' => '2', 'Maret' => '3', 'April' => '4', 'Mei' => '5', 'Juni' => '6', 'Juli' => '7', 'Agustus' => '8', 'September' => '9', 'Oktober' => '10', 'November' => '11', 'Desember' => '12'];
                                ?>
                                <option value="<?php echo e($tgl); ?>">Pilih Bulan</option>
                                <?php $__currentLoopData = $bulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b => $value_bulan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value_bulan); ?>"><?php echo e($b); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                            <button type="submit" class="btn btn-primary my-2">Cari</button>
                            <?php if(isset($periode)): ?>
                                <a href="<?php echo e(route('print', $periode)); ?>" class="btn btn-success my-2 mx-2"
                                    target="_blank">Print</a>
                            <?php else: ?>
                                <a href="<?php echo e(route('print1')); ?>" class="btn btn-success my-2 mx-2"
                                    target="_blank">Print</a>
                            <?php endif; ?>
                            
                        </div>
                    </form>
                    <div class="pb-20">
                        <table class="data-table table table-bordered">
                            <thead>
                                <tr>
                                    <td colspan="3">
                                        <h5> Pendapatan </h5>
                                    </td>
                                    <td colspan="5 ">
                                        <h5>Pengeluaran </h5>
                                    </td>
                                    <td>
                                        <h5>Saldo </h5>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Tanggal</th>
                                    <th>Sumber</th>
                                    <th>Jumlah</th>
                                    <th>Tanggal</th>
                                    <th>Keterangan</th>
                                    <th>Satuan</th>
                                    <th>Banyak</th>
                                    <th>Jumlah</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="text center">

                                        <td><?php echo e($t->tanggal_pendapatan); ?></td>
                                        <td><?php echo e($t->sumber); ?></td>
                                        <td><?php echo e(number_format($t->jumlah_pendapatan)); ?></td>
                                        <td><?php echo e($t->tanggal_pengeluaran); ?></td>
                                        <td><?php echo e($t->keterangan); ?></td>
                                        <td><?php echo e($t->satuan); ?></td>
                                        <td><?php echo e($t->banyak); ?></td>
                                        <td><?php echo e(number_format($t->jumlah_pengeluaran)); ?></td>
                                        <td><?php echo e(number_format($t->jumlah_pendapatan - $t->jumlah_pengeluaran)); ?></td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tr>
                                <td colspan="2">Total Pendapatan</td>
                                <td>Rp.<?php echo e(number_format($jumlah->pendapatan)); ?></td>
                                <td colspan="4">Total Pengeluaran</td>
                                <td>Rp.<?php echo e(number_format($jumlah->pengeluaran)); ?></td>
                                <td>Rp.<?php echo e(number_format($jumlah->pendapatan - $jumlah->pengeluaran)); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\project_skripsi\kodingan\sistem_informasi_managemnt_keuangan\sim-laravel\resources\views/halaman_bendahara/laporan/laporan_keungan_bulanan.blade.php ENDPATH**/ ?>