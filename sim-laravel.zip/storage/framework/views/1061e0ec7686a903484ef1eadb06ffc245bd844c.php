

<?php $__env->startSection('content'); ?>
    <div class="main-container">
        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="page-header">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="title">
                                <h4>Detail Laporan Kas Tahunan
                                </h4>
                            </div>
                            <nav aria-label="breadcrumb" role="navigation">
                            </nav>
                        </div>
                    </div>
                </div>

                <div class="pd-20 bg-white border-radius-4 box-shadow mb-30">
                    <?php
                        date_default_timezone_set('Asia/Jakarta');
                        $tgl = date('Y');
                    ?>
                    <form action="<?php echo e(route('cari_tahunan')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row float-center">

                            <select class="form-control" name="periode_tahunan" aria-label="Default select example">
                                <?php
                                    $bulan = ['2021', '2022', '2023', '2024', '2025', '2026'];
                                ?>
                                <option value="<?php echo e($tgl); ?>">Pilih Bulan</option>
                                <?php $__currentLoopData = $bulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b => $value_tahunan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value_tahunan); ?>"><?php echo e($value_tahunan); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                            <button type="submit" class="btn btn-primary my-2">Cari</button>
                            <?php if(isset($periode_tahunan)): ?>
                                <a href="<?php echo e(route('print_tahun', $periode_tahunan)); ?>" class="btn btn-success my-2 mx-2"
                                    target="_blank">Print</a>
                            <?php else: ?>
                                <a href="<?php echo e(route('print_tahun1')); ?>" class="btn btn-success my-2 mx-2"
                                    target="_blank">Print</a>
                            <?php endif; ?>
                        </div>
                    </form>
                    <div class="pb-20">
                        <table class="data-table table table-bordered">
                            <thead>
                                <tr>
                                    <th>Bulan</th>
                                    <th>Masuk</th>
                                    <th>Keluar</th>
                                    <th>Saldo</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $tahunan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="text center">
                                        <td>
                                            <?php if($t->pengeluaran_bulan == 12): ?>
                                                <?php echo e('Desember'); ?>

                                            <?php elseif($t->pengeluaran_bulan == 11): ?>
                                                <?php echo e('November'); ?>

                                            <?php elseif($t->pengeluaran_bulan == 10): ?>
                                                <?php echo e('October'); ?>

                                            <?php elseif($t->pengeluaran_bulan == 9): ?>
                                                <?php echo e('September'); ?>

                                            <?php elseif($t->pengeluaran_bulan == 8): ?>
                                                <?php echo e('Agustus'); ?>

                                            <?php elseif($t->pengeluaran_bulan == 7): ?>
                                                <?php echo e('Juli'); ?>

                                            <?php elseif($t->pengeluaran_bulan == 6): ?>
                                                <?php echo e('Juni'); ?>

                                            <?php elseif($t->pengeluaran_bulan == 5): ?>
                                                <?php echo e('May'); ?>

                                            <?php elseif($t->pengeluaran_bulan == 4): ?>
                                                <?php echo e('April'); ?>

                                            <?php elseif($t->pengeluaran_bulan == 3): ?>
                                                <?php echo e('Maret'); ?>

                                            <?php elseif($t->pengeluaran_bulan == 2): ?>
                                                <?php echo e('February'); ?>

                                            <?php elseif($t->pengeluaran_bulan == 1): ?>
                                                <?php echo e('January'); ?>

                                            <?php endif; ?>

                                        </td>
                                        <td><?php echo e(number_format($t->TotalPendapatan)); ?></td>
                                        <td><?php echo e(number_format($t->TotalPengeluaran)); ?></td>
                                        <td><?php echo e(number_format($t->TotalPendapatan - $t->TotalPengeluaran)); ?></td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\project_skripsi\kodingan\sistem_informasi_managemnt_keuangan\sim-laravel\resources\views/halaman_bendahara/laporan/laporan_keuangan_tahunan.blade.php ENDPATH**/ ?>