<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php echo $__env->make('pembagian_template.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('pembagian_template.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    
    <div class="pd-ltr-20 xs-pd-20-10">
        <div class="min-height-200px">

            <div class="pd-20 bg-white border-radius-4 box-shadow mb-30">
                <div class="pb-20 mt-5">
                    <?php if(isset($siswa_print)): ?>
                        <?php
                            $nama_siswa = DB::table('siswa')
                                ->where('nama_siswa', $siswa_print)
                                ->leftjoin('kelas', 'siswa.id_kelas', '=', 'kelas.id_kelas')
                                ->first();
                        ?>
                    <?php endif; ?>
                    NAMA SISWA :<?php echo e($nama_siswa->nama_siswa); ?> <br>
                    NIS : <?php echo e($nama_siswa->nis); ?> <br>
                    KELAS : <?php echo e($nama_siswa->kelas); ?> (<?php echo e($nama_siswa->nama_kelas); ?>)<br>
                    <div class="container">

                    </div>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Bulan</th>
                                <th>Uang SPP</th>
                                <th>Uang SERAGAM</th>
                                <th>UANG DSP</th>
                                <th>UANG UJIAN</th>
                                <th>JUMLAH</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $print_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text center">
                                    <td>
                                        <?php if($t->bulan_semua == 12): ?>
                                            <?php echo e('Desember'); ?>

                                        <?php elseif($t->bulan_semua == 11): ?>
                                            <?php echo e('November'); ?>

                                        <?php elseif($t->bulan_semua == 10): ?>
                                            <?php echo e('October'); ?>

                                        <?php elseif($t->bulan_semua == 9): ?>
                                            <?php echo e('September'); ?>

                                        <?php elseif($t->bulan_semua == 8): ?>
                                            <?php echo e('Agustus'); ?>

                                        <?php elseif($t->bulan_semua == 7): ?>
                                            <?php echo e('Juli'); ?>

                                        <?php elseif($t->bulan_semua == 6): ?>
                                            <?php echo e('Juni'); ?>

                                        <?php elseif($t->bulan_semua == 5): ?>
                                            <?php echo e('May'); ?>

                                        <?php elseif($t->bulan_semua == 4): ?>
                                            <?php echo e('April'); ?>

                                        <?php elseif($t->bulan_semua == 3): ?>
                                            <?php echo e('Maret'); ?>

                                        <?php elseif($t->bulan_semua == 2): ?>
                                            <?php echo e('February'); ?>

                                        <?php elseif($t->bulan_semua == 1): ?>
                                            <?php echo e('January'); ?>

                                        <?php endif; ?>

                                    </td>
                                    <td><?php echo e(number_format($t->TotalSPP)); ?></td>
                                    <td><?php echo e(number_format($t->TotalSeragam)); ?></td>
                                    <td><?php echo e(number_format($t->TotalDSP)); ?></td>
                                    <td><?php echo e(number_format($t->TotalUjian)); ?></td>
                                    <td><?php echo e(number_format($t->TotalSPP + $t->TotalSeragam + $t->TotalDSP + $t->TotalUjian)); ?>

                                    </td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
            <div class="container-fluid">
                <div class="d-flex justify-content-between">
                    <?php
                        date_default_timezone_set('Asia/Jakarta');
                        $tanggal = date('Y-m-d');
                    ?>
                    <div class="row">Mengetahui : <br> Kepala Sekolah Smk Cendana Padang Panjang
                        <br><br><br><br><br> Drs. Khalil Taj <br>Nip:
                    </div>
                    <div class="row">Padang Panjang ,<?php echo e($tanggal); ?> <br>Bendahara
                        <br><br><br><br><br>Eva Erianti S.Pd
                        <br>Nip:
                    </div>
                </div>
            </div>
            
        </div>
    </div>

</body>
<script>
    window.print();
</script>

</html>
<?php /**PATH D:\xampp\htdocs\project_skripsi\kodingan\sistem_informasi_managemnt_keuangan\sim-laravel\resources\views/halaman_bendahara/print/print_keuangan_siswa.blade.php ENDPATH**/ ?>