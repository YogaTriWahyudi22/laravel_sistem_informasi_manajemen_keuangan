

<?php $__env->startSection('content'); ?>

    <div class="main-container">
        <div class="pd-ltr-20">
            <div class="card-box pd-20 height-100-p mb-30">
                <div class="row align-items-center">
                    <div class="col-md-4">
                        <img src="<?php echo e(asset('vendors/images/banner-img.png')); ?>" alt="">
                    </div>
                    <div class="col-md-8">
                        <h4 class="font-20 weight-500 mb-10 text-capitalize">
                            Welcome back <div class="weight-600 font-30 text-blue"><?php echo e(Auth::user()->nama); ?></div>
                        </h4>
                        
                    </div>
                </div>
            </div>
            <?php if(Auth::user()->status !== 'admin'): ?>

                <div class="row">
                    
                    
                    
                    
                </div>
            <?php endif; ?>
            <div class="card-box mb-30">
                <h2 class="h4 pd-20"></h2>
                <div class="container">
                    <center>
                        <img src="<?php echo e(asset('gambar/logo2.png')); ?>" alt="">
                        <h3>SISTEM INFORMASI ADMINISTRASI KEUANGAN <br>
                            SMK CENDANA PADANG PANJANG</h3>
                    </center>
                </div>
            </div>
            <div class="footer-wrap pd-20 mb-20 card-box">
                DeskApp - Bootstrap 4 Admin Template By <a href="https://github.com/dropways" target="_blank">Ankit
                    Hingarajiya</a>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\project_skripsi\kodingan\sistem_informasi_managemnt_keuangan\sim-laravel\resources\views/halaman_admin/dashboard/dashboard.blade.php ENDPATH**/ ?>