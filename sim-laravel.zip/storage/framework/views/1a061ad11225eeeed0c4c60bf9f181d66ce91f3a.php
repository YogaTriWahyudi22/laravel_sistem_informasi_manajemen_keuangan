                        <!-- Modal -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                            aria-hidden="true">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Pendaftaran / Tambah Data</h5>
                                        <button type="button" class="close" data-dismiss="modal"
                                            aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="<?php echo e(route('pendaftaran_tambah')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>

                                            <div class="form-group">
                                                <label>Nama Siswa</label>
                                                <input class="form-control" name="nama_siswa"
                                                    placeholder="inputkan nama Siswa" type="text" required>
                                            </div>

                                            <div class="form-group">
                                                <label>NIS</label>
                                                <input class="form-control" name="nis" placeholder="Inputkan NIS"
                                                    type="text" required>
                                            </div>

                                            <div class="form-group">
                                                <label>Pilih Jurusan</label>
                                                <select class="form-control" name="id_jurusan"
                                                    aria-label="Default select example">
                                                    <option selected>Pilih Jurusan</option>
                                                    <?php
                                                        $jurusan = DB::table('jurusan')->get();
                                                    ?>
                                                    <?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($j->id_jurusan); ?>"><?php echo e($j->nama_jurusan); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>

                                            <div class="form-group">
                                                <label>Jenis Kelamin</label>
                                                <select class="custom-select col-12" name="jk" required>
                                                    <option selected="">Pilih Jenis Kelamin...</option>
                                                    <option value="laki-laki">laki-laki</option>
                                                    <option value="perempuan">perempuan</option>
                                                </select>
                                            </div>

                                            <div class="form-group">
                                                <label>Tanggal Lahir</label>
                                                <input class="form-control" name="tanggal_lahir"
                                                    placeholder="Inputkan Tanggal Lahir" type="date" required>
                                            </div>

                                            <div class="form-group">
                                                <label>Wali SIswa</label>
                                                <input class="form-control" name="wali_siswa"
                                                    placeholder="Inputkan Wali Siswa" type="text" required>
                                            </div>

                                            <div class="form-group">
                                                <label>Alamat</label>
                                                <input class="form-control" name="alamat_siswa"
                                                    placeholder="Inputkan Alamat" type="text" required>
                                            </div>

                                            <button class="btn btn-primary" type="submit">Submit</button>
                                            <a href="<?php echo e(route('pendaftaran')); ?>" class="btn btn-danger">Kembali</a>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
<?php /**PATH D:\xampp\htdocs\project_skripsi\kodingan\sistem_informasi_managemnt_keuangan\sim-laravel\resources\views/halaman_bendahara/pendaftaran/tambah.blade.php ENDPATH**/ ?>