

<?php $__env->startSection('content'); ?>
    <div class="main-container">
        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="page-header">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="title">
                                <h4>Data Pembayaran Uang DSP <a href="<?php echo e(route('dsp')); ?>"
                                        class="btn btn-info">Kembali</a></h4>
                            </div>
                            <nav aria-label="breadcrumb" role="navigation">
                            </nav>
                        </div>
                    </div>
                </div>
                <div class="pd-20 bg-white border-radius-4 box-shadow mb-30">
                    <?php if(isset($nama)): ?>
                        <h3 class="text-capitalize">Nama : <?php echo e($nama->nama_siswa); ?></h3>
                    <?php endif; ?>
                    <div class="pb-20">
                        <table class="data-table table stripe hover nowrap">
                            <thead>
                                <tr>
                                    <th class="table-plus datatable-nosort">Nomor</th>
                                    <th>Waktu Pembayaran</th>
                                    <th>Nomonal</th>
                                    <th>Keterangan</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="table-plus"><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e(date('d/F/Y', strtotime($i->tanggal))); ?>/ <?php echo e($i->waktu); ?></td>
                                        <td>Rp.<?php echo e(number_format($i->nominal)); ?></td>
                                        <td class="text-capitalize"> <?php echo e($i->keterangan); ?></td>
                                        <td class="text-capitalize"><?php echo e($i->status); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\project_skripsi\kodingan\sistem_informasi_managemnt_keuangan\sim-laravel\resources\views/halaman_bendahara/uang_dsp/detail.blade.php ENDPATH**/ ?>