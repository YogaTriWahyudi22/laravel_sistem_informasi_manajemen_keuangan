

<?php $__env->startSection('user'); ?>

    <div class="login-wrap d-flex align-items-center flex-wrap justify-content-center">
        
        <div class="row align-items-center">
            <div class="col-md-12 col-lg-12">
                <center>
                    <h3 style="color: #455a64">Sistem Informasi Administrasi Keuangan <br> SMK Cendana Padang
                        Panjang
                    </h3>
                    <img src="<?php echo e(asset('vendors/images/login-page-img.png')); ?>" alt="">
                </center>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\project_skripsi\kodingan\sistem_informasi_managemnt_keuangan\sim-laravel\resources\views/halaman_utama/index.blade.php ENDPATH**/ ?>