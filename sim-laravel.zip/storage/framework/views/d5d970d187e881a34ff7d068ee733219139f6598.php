

<?php $__env->startSection('content'); ?>
    <div class="main-container">
        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="page-header">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="title">
                                <h4>Data Pembayaran Gaji Guru</h4>
                            </div>
                            <nav aria-label="breadcrumb" role="navigation">
                            </nav>
                        </div>
                    </div>
                </div>
                <div class="pd-20 bg-white border-radius-4 box-shadow mb-30">
                    <div class="pd-20">
                    </div>
                    <div class="pd-20 bg-white border-radius-4 box-shadow mb-30">
                        <div class="pb-20">
                            <table class="data-table table stripe hover nowrap">
                                <thead>
                                    <tr>
                                        <th class="table-plus datatable-nosort">Nomor</th>
                                        <th>Nama Guru</th>
                                        <th>NIP</th>
                                        <th>Jenis Kelamin</th>
                                        <th>Nomor Telepon</th>
                                        <th>Bidang</th>
                                        <th class="datatable-nosort">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $gaji; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="text center">
                                            <td class="table-plus"><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($i->nama_guru); ?></td>
                                            <td><?php echo e($i->nip); ?></td>
                                            <td><?php echo e($i->jk); ?></td>
                                            <td><?php echo e($i->nohp); ?></td>
                                            <td><?php echo e($i->bidang); ?></td>
                                            <td>
                                                <div class="btn-group" role="group" aria-label="Basic example">

                                                    <a href="" class="btn btn-success" class="btn btn-primary" id="pilih"
                                                        onchange="kategori()" data-toggle="modal"
                                                        data-target="#guru<?php echo e($i->id_guru); ?>"><span
                                                            class="text-capitalize">Pembayaran Gaji</span></a>

                                                    <a href="<?php echo e(route('pembayaran_gaji_detail', $i->id_guru)); ?>"
                                                        class="btn btn-info mx-2">
                                                        Detail</a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>

    <?php $__currentLoopData = $gaji; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- Modal -->
        <div class="modal fade" id="guru<?php echo e($k->id_guru); ?>" tabindex="-1" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel"><span class="text-capitalize">Form Pembayaran Gaji
                                Guru</span>
                        </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <?php
                            $t = Date('Y');
                            $b = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
                        ?>
                        <form action="<?php echo e(route('pembayaran_gaji_tambah')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <select class="form-control" name="periode" aria-label="Default select example" required>
                                <option selected>Pilih Kelas</option>
                                <?php $__currentLoopData = $b; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?= $i . '-' . $t ?>"><?= $i . '-' . $t ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <input type="hidden" name="id_guru" value="<?php echo e($k->id_guru); ?>">
                            <div class="form-group">
                                <label class="control-label"> Jam Kerja</label>
                                <div><input type="text" name="jam" name="nominal" class="form-control" id="jam"></div>
                            </div>

                            <div class="form-group">
                                <label class="control-label"> Nominal</label>
                                <div>
                                    <input type="text" readonly="" name="nominal" class="form-control" id="total">
                                </div>
                            </div>

                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal"><span
                                        class="text-capitalize">tutup</span></button>
                                <button type="submit" class="btn btn-primary"><span
                                        class="text-capitalize">simpan</span></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <script>
        $(document).ready(function() {
            let jam = document.getElementById("jam")
            jam.addEventListener('keyup', function() {
                let total = "40000"
                document.getElementById("total").value = parseInt(total) * parseInt(this.value)
            });
        });

        function kategori() {
            var tes = document.getElementById("pilih").value;
            console.log(tes);
            $('#kelassaya' + tes).modal('show');

        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\project_skripsi\kodingan\sistem_informasi_managemnt_keuangan\sim-laravel\resources\views/halaman_bendahara/gaji_guru/index.blade.php ENDPATH**/ ?>