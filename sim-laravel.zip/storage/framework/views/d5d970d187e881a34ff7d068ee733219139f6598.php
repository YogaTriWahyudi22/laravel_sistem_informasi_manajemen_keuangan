

<?php $__env->startSection('content'); ?>
    <div class="main-container">
        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="page-header">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="title">
                                <h4>Data Pembayaran Gaji Guru</h4>
                            </div>
                            <nav aria-label="breadcrumb" role="navigation">
                            </nav>
                        </div>
                    </div>
                </div>
                <div class="pd-20 bg-white border-radius-4 box-shadow mb-30">
                    <div class="pd-20">
                        <a href="<?php echo e(route('pembayaran_gaji_tambah_get')); ?>" class="btn btn-primary" class="btn btn-primary"
                            id="pilih"><span class="text-capitalize">Pembayaran Gaji</span></a>
                    </div>
                    <div class="pd-20 bg-white border-radius-4 box-shadow mb-30">
                        <div class="pb-20">
                            <table class="data-table table stripe hover nowrap">
                                <thead>
                                    <tr>
                                        <th class="table-plus datatable-nosort">Nomor</th>
                                        <th>Nama Guru</th>
                                        <th>NIP</th>
                                        <th>Jenis Kelamin</th>
                                        <th>Nomor Telepon</th>
                                        <th>Bidang</th>
                                        <th class="datatable-nosort">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $gaji; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="text center">
                                            <td class="table-plus"><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($i->nama_guru); ?></td>
                                            <td><?php echo e($i->nip); ?></td>
                                            <td><?php echo e($i->jk); ?></td>
                                            <td><?php echo e($i->nohp); ?></td>
                                            <td><?php echo e($i->bidang); ?></td>
                                            <td>
                                                <div class="btn-group" role="group" aria-label="Basic example">

                                                    <a href="<?php echo e(route('pembayaran_gaji_detail', $i->id_guru)); ?>"
                                                        class="btn btn-info mx-2">
                                                        Detail</a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            let jam = document.getElementById("jam")
            jam.addEventListener('keyup', function() {
                let total = "40000"
                document.getElementById("total").value = parseInt(total) * parseInt(this.value)
            });
        });

        function kategori() {
            var tes = document.getElementById("pilih").value;
            console.log(tes);
            $('#guru' + tes).modal('show');

        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\project_skripsi\kodingan\sistem_informasi_managemnt_keuangan\sim-laravel\resources\views/halaman_bendahara/gaji_guru/index.blade.php ENDPATH**/ ?>