<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php echo $__env->make('pembagian_template.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('pembagian_template.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    
    <div class="pd-ltr-20 xs-pd-20-10">
        <div class="min-height-200px">

            <div class="pd-20 bg-white border-radius-4 box-shadow mb-30">
                <div class="pb-20">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <td colspan="3">
                                    <h5> Pendapatan </h5>
                                </td>
                                <td colspan="5 ">
                                    <h5>Pengeluaran </h5>
                                </td>
                                <td>
                                    <h5>Saldo </h5>
                                </td>
                            </tr>
                            <tr>
                                <th>Tanggal</th>
                                <th>Sumber</th>
                                <th>Jumlah</th>
                                <th>Tanggal</th>
                                <th>Keterangan</th>
                                <th>Satuan</th>
                                <th>Banyak</th>
                                <th>Jumlah</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text center">

                                    <td><?php echo e($t->tanggal_pendapatan); ?></td>
                                    <td><?php echo e($t->sumber); ?></td>
                                    <td><?php echo e(number_format($t->jumlah_pendapatan)); ?></td>
                                    <td><?php echo e($t->tanggal_pengeluaran); ?></td>
                                    <td><?php echo e($t->keterangan); ?></td>
                                    <td><?php echo e($t->satuan); ?></td>
                                    <td><?php echo e($t->banyak); ?></td>
                                    <td><?php echo e(number_format($t->jumlah_pengeluaran)); ?></td>
                                    <td><?php echo e(number_format($t->jumlah_pendapatan - $t->jumlah_pengeluaran)); ?></td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tr>
                            <td colspan="2">Total Pendapatan</td>
                            <td>Rp.<?php echo e(number_format($jumlah->pendapatan)); ?></td>
                            <td colspan="4">Total Pengeluaran</td>
                            <td>Rp.<?php echo e(number_format($jumlah->pengeluaran)); ?></td>
                            <td>Rp.<?php echo e(number_format($jumlah->pendapatan - $jumlah->pengeluaran)); ?></td>
                        </tr>
                    </table>
                </div>
            </div>

            <div class="container-fluid">
                <div class="d-flex justify-content-between">
                    <?php
                        date_default_timezone_set('Asia/Jakarta');
                        $tanggal = date('Y-m-d');
                    ?>
                    <div class="row">Mengetahui : <br> Kepala Sekolah Smk Cendana Padang Panjang
                        <br><br><br><br><br> Drs. Khalil Taj <br>Nip:
                    </div>
                    <div class="row">Padang Panjang ,<?php echo e($tanggal); ?> <br>Bendahara
                        <br><br><br><br><br>Eva Erianti S.Pd
                        <br>Nip:
                    </div>
                </div>
            </div>
        </div>
    </div>
    

</body>
<script>
    window.print();
</script>

</html>
<?php /**PATH D:\xampp\htdocs\project_skripsi\kodingan\sistem_informasi_managemnt_keuangan\sim-laravel\resources\views/halaman_bendahara/print/print.blade.php ENDPATH**/ ?>