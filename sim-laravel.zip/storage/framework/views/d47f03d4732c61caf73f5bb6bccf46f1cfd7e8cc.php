<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php echo $__env->make('pembagian_template.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('pembagian_template.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    
    <div class="pd-ltr-20 xs-pd-20-10">
        <div class="min-height-200px">

            <div class="pd-20 bg-white border-radius-4 box-shadow mb-30">
                <div class="pb-20">
                    <div class="container mt-5">
                        <h2>LAPORAN KEUANGAN TAHUNAN SMK CENDANA PADANG PANJANG</h2>
                    </div>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Bulan</th>
                                <th>Masuk</th>
                                <th>Keluar</th>
                                <th>Saldo</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $tahunan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text center">
                                    <td>
                                        <?php if($t->pengeluaran_bulan == 12): ?>
                                            <?php echo e('Desember'); ?>

                                        <?php elseif($t->pengeluaran_bulan == 11): ?>
                                            <?php echo e('November'); ?>

                                        <?php elseif($t->pengeluaran_bulan == 10): ?>
                                            <?php echo e('October'); ?>

                                        <?php elseif($t->pengeluaran_bulan == 9): ?>
                                            <?php echo e('September'); ?>

                                        <?php elseif($t->pengeluaran_bulan == 8): ?>
                                            <?php echo e('Agustus'); ?>

                                        <?php elseif($t->pengeluaran_bulan == 7): ?>
                                            <?php echo e('Juli'); ?>

                                        <?php elseif($t->pengeluaran_bulan == 6): ?>
                                            <?php echo e('Juni'); ?>

                                        <?php elseif($t->pengeluaran_bulan == 5): ?>
                                            <?php echo e('May'); ?>

                                        <?php elseif($t->pengeluaran_bulan == 4): ?>
                                            <?php echo e('April'); ?>

                                        <?php elseif($t->pengeluaran_bulan == 3): ?>
                                            <?php echo e('Maret'); ?>

                                        <?php elseif($t->pengeluaran_bulan == 2): ?>
                                            <?php echo e('February'); ?>

                                        <?php elseif($t->pengeluaran_bulan == 1): ?>
                                            <?php echo e('January'); ?>

                                        <?php endif; ?>

                                    </td>
                                    <td><?php echo e(number_format($t->TotalPendapatan)); ?></td>
                                    <td><?php echo e(number_format($t->TotalPengeluaran)); ?></td>
                                    <td><?php echo e(number_format($t->TotalPendapatan - $t->TotalPengeluaran)); ?></td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="container-fluid">
                <div class="d-flex justify-content-between">
                    <?php
                        date_default_timezone_set('Asia/Jakarta');
                        $tanggal = date('Y-m-d');
                    ?>
                    <div class="row">Mengetahui : <br> Kepala Sekolah Smk Cendana Padang Panjang
                        <br><br><br><br><br> Drs. Khalil Taj <br>Nip:
                    </div>
                    <div class="row">Padang Panjang ,<?php echo e($tanggal); ?> <br>Bendahara
                        <br><br><br><br><br>Eva Erianti S.Pd
                        <br>Nip:
                    </div>
                </div>
            </div>
            
        </div>
    </div>

</body>
<script>
    window.print();
</script>

</html>
<?php /**PATH D:\xampp\htdocs\project_skripsi\kodingan\sistem_informasi_managemnt_keuangan\sim-laravel\resources\views/halaman_bendahara/print/print_tahunan.blade.php ENDPATH**/ ?>