

<?php $__env->startSection('content'); ?>
    <div class="main-container">
        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="page-header">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="title">
                                <h4>Data Pembayaran Uang Seragam</h4>
                            </div>
                            <nav aria-label="breadcrumb" role="navigation">
                            </nav>
                        </div>
                    </div>
                </div>
                <div class="pd-20 bg-white border-radius-4 box-shadow mb-30">
                    <div class="pd-20">
                        <form action="<?php echo e(route('uang_seragam_cari')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <select class="form-control" name="cari" aria-label="Default select example">
                                <option value="0">Pilih Kelas</option>

                                <?php $__currentLoopData = $pilih_kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($k->id_kelas); ?>"><?php echo e($k->nama_kelas); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <button style="submit" class="btn btn-primary mt-2">Cari</button>
                        </form>
                    </div>
                    <div class="pd-20 bg-white border-radius-4 box-shadow mb-30">
                        <div class="pb-20">
                            <table class="data-table table stripe hover nowrap">
                                <thead>
                                    <tr>
                                        <th class="table-plus datatable-nosort">Nomor</th>
                                        <th>Nama Siswa</th>
                                        <th>NIS</th>
                                        <th>Jurusan</th>
                                        <th>Jenis Kelamin</th>
                                        <th>Status Pembayaran</th>
                                        <th class="datatable-nosort">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="text center">
                                            <td class="table-plus"><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($i->nama_siswa); ?></td>
                                            <td><?php echo e($i->nis); ?></td>
                                            <td><?php echo e($i->nama_jurusan); ?></td>
                                            <td><?php echo e($i->jk); ?></td>
                                            <td><?php echo e($i->status_uang); ?></td>
                                            <td>
                                                <div class="btn-group" role="group" aria-label="Basic example">
                                                    <?php if($i->status_uang == 'lunas'): ?>

                                                    <?php else: ?>
                                                        <a href="" class="btn btn-success" class="btn btn-primary"
                                                            id="pilih" onchange="kategori()" data-toggle="modal"
                                                            data-target="#pembayaran<?php echo e($i->id_siswa); ?>"><span
                                                                class="text-capitalize">bayar</span></a>
                                                    <?php endif; ?>

                                                    <a href="<?php echo e(route('uang_seragam_detail', $i->id_siswa)); ?>"
                                                        class="btn btn-info mx-2">
                                                        Detail</a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
    <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <!-- Modal -->
        <div class="modal fade" id="pembayaran<?php echo e($k->id_siswa); ?>" tabindex="-1" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel"><span class="text-capitalize"> Form Pembayaran
                                Uang Seragam</span>
                        </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('uang_seragam_ujian')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id_siswa" value="<?php echo e($k->id_siswa); ?>">
                            <div class="form-group">
                                <label class="control-label"> Nominal</label>
                                <div><input type="text" readonly="" value="<?php echo e($pembayaran->nominal); ?>" name="nominal"
                                        class="form-control"></div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal"><span
                                        class="text-capitalize">tutup</span></button>
                                <button type="submit" class="btn btn-primary"><span
                                        class="text-capitalize">simpan</span></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <script>
        function kategori() {
            var tes = document.getElementById("pilih").value;
            console.log(tes);
            $('#kelassaya' + tes).modal('show');

        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\project_skripsi\kodingan\sistem_informasi_managemnt_keuangan\sim-laravel\resources\views/halaman_bendahara/uang_seragam/index.blade.php ENDPATH**/ ?>