
<?php if(Auth::user()): ?>
    <div class="header">
        <div class="header-left">
            <div class="menu-icon dw dw-menu"></div>
        </div>
        <div class="header-right">
            <div class="user-info-dropdown">
                <div class="dropdown">
                    <a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown">
                        <span class="user-icon">
                            <i class="fa fa-user"></i>
                        </span>
                        <span class="user-name"><?php echo e(Auth::user()->nama); ?></span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-icon-list">
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"><i class="dw dw-logout"></i> Log
                            Out</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\project_skripsi\kodingan\sistem_informasi_managemnt_keuangan\sim-laravel\resources\views/pembagian_template/header.blade.php ENDPATH**/ ?>