    <!-- js -->
    <script src="<?php echo e(asset('vendors/scripts/core.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/scripts/script.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/scripts/process.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/scripts/layout-settings.js')); ?>"></script>

    <script src="<?php echo e(asset('src/plugins/datatables/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('src/plugins/datatables/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('src/plugins/datatables/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('src/plugins/datatables/js/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/scripts/dashboard.js')); ?>"></script>

    <!-- Datatable Setting js -->
    <script src="<?php echo e(asset('vendors/scripts/datatable-setting.js')); ?>"></script></body>
<?php /**PATH D:\xampp\htdocs\project_skripsi\kodingan\sistem_informasi_managemnt_keuangan\sim-laravel\resources\views/pembagian_template/script.blade.php ENDPATH**/ ?>