

<?php $__env->startSection('content'); ?>
    <div class="main-container">
        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="page-header">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="title">
                                <h4>Detail Laporan Kas <a href="<?php echo e(route('laporan')); ?>" class="btn btn-primary">Kembali</a>
                                </h4>
                            </div>
                            <nav aria-label="breadcrumb" role="navigation">
                            </nav>
                        </div>
                    </div>
                </div>
                <div class="pd-20 bg-white border-radius-4 box-shadow mb-30">
                    <h2> Kas Masuk </h2>
                    <hr>
                    <?php if(isset($pendaftaran)): ?>
                        <div class="pb-20">
                            <h5 style="background-color: #7CB9E8">Uang Pendaftaran</h5>
                            <table class="table stripe hover nowrap">
                                <thead>
                                    <tr>
                                        <th class="table-plus datatable-nosort">Nomor</th>
                                        <th>Nama Siswa</th>
                                        <th>Nominal</th>
                                        <th>Tanggal</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $pendaftaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="text center">
                                            <td class="table-plus"><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($i->nama_siswa); ?></td>
                                            <td><?php echo e(number_format($i->nominal)); ?></td>
                                            <td><?php echo e($i->tanggal); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                    <?php if(isset($uang_spp)): ?>

                        <div class="pb-20">
                            <h5 style="background-color: #fd5c63">Uang SPP</h5>
                            <table class="table stripe hover nowrap">
                                <thead>
                                    <tr>
                                        <th class="table-plus datatable-nosort">Nomor</th>
                                        <th>Nama Siswa</th>
                                        <th>Bulan</th>
                                        <th>Nominal</th>
                                        <th>Tanggal</th>
                                        <th>Waktu</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $uang_spp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="text center">
                                            <td class="table-plus"><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($spp->nama_siswa); ?></td>
                                            <td><?php echo e($spp->bulan); ?></td>
                                            <td><?php echo e(number_format($spp->nominal)); ?></td>
                                            <td><?php echo e($spp->tanggal); ?></td>
                                            <td><?php echo e($spp->waktu); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                    <?php if(isset($uang_pkl)): ?>
                        <div class="pb-20">
                            <h5 style="background-color: #00BFFF">Uang PKL</h5>
                            <table class="table stripe hover nowrap">
                                <thead>
                                    <tr>
                                        <th class="table-plus datatable-nosort">Nomor</th>
                                        <th>Nama Siswa</th>
                                        <th>Nominal</th>
                                        <th>Keterangan</th>
                                        <th>Status</th>
                                        <th>Tanggal</th>
                                        <th>Waktu</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $uang_pkl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pkl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="text center">
                                            <td class="table-plus"><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($pkl->nama_siswa); ?></td>
                                            <td><?php echo e(number_format($pkl->nominal)); ?></td>
                                            <td><?php echo e($pkl->keterangan); ?></td>
                                            <td><?php echo e($pkl->tanggal); ?></td>
                                            <td><?php echo e($pkl->waktu); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>

                    <?php if(isset($uang_seragam)): ?>
                        <div class="pb-20">
                            <h5 style="background-color: #568203">Uang Seragam</h5>
                            <table class="table stripe hover nowrap">
                                <thead>
                                    <tr>
                                        <th class="table-plus datatable-nosort">Nomor</th>
                                        <th>Nama Siswa</th>
                                        <th>Nominal</th>
                                        <th>Status</th>
                                        <th>Tanggal</th>
                                        <th>Waktu</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $uang_seragam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seragam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="text center">
                                            <td class="table-plus"><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($seragam->nama_siswa); ?></td>
                                            <td><?php echo e(number_format($seragam->nominal)); ?></td>
                                            <td><?php echo e($seragam->status); ?></td>
                                            <td><?php echo e($seragam->tanggal); ?></td>
                                            <td><?php echo e($seragam->waktu); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>

                    <?php if(isset($uang_ujian)): ?>
                        <div class="pb-20">
                            <h5 style="background-color: #B9D9EB">Uang Ujian</h5>
                            <table class="table stripe hover ">
                                <thead>
                                    <tr>
                                        <th class="table-plus datatable-nosort">Nomor</th>
                                        <th>Nama Siswa</th>
                                        <th>Nominal</th>
                                        <th>Periode</th>
                                        <th>Tanggal</th>
                                        <th>Waktu</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $uang_ujian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ujian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="text center">
                                            <td class="table-plus"><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($ujian->nama_siswa); ?></td>
                                            <td><?php echo e(number_format($ujian->nominal)); ?></td>
                                            <td><?php echo e($ujian->periode); ?></td>
                                            <td><?php echo e($ujian->tanggal); ?></td>
                                            <td><?php echo e($ujian->waktu); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>

                </div>

                <div class="pd-20 bg-white border-radius-4 box-shadow mb-30">
                    <h2> Kas Keluar </h2>
                    <hr>
                    <?php if(isset($biaya_lain)): ?>
                        <div class="pb-20">
                            <h5 style="background-color: #FF7F50">Biaya Lain</h5>
                            <table class="table stripe hover nowrap">
                                <thead>
                                    <tr>
                                        <th class="table-plus datatable-nosort">Nomor</th>
                                        <th>Nama Admin</th>
                                        <th>Keterangan</th>
                                        <th>Nominal</th>
                                        <th>Tanggal</th>
                                        <th>Waktu</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $biaya_lain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="text center">
                                            <td class="table-plus"><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($lain->nama); ?></td>
                                            <td><?php echo e($lain->keterangan); ?></td>
                                            <td><?php echo e(number_format($lain->nominal)); ?></td>
                                            <td><?php echo e($lain->tanggal); ?></td>
                                            <td><?php echo e($lain->waktu); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>

                    <?php if(isset($gaji)): ?>
                        <div class="pb-20">
                            <h5 style="background-color: #4FFFB0">Gaji</h5>
                            <table class="data-table table stripe hover nowrap">
                                <thead>
                                    <tr>
                                        <th class="table-plus datatable-nosort">Nomor</th>
                                        <th>Nama Guru</th>
                                        <th>Periode</th>
                                        <th>Jam Mengejar</th>
                                        <th>Nominal</th>
                                        <th>Tanggal</th>
                                        <th>Waktu</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $gaji; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="text center">
                                            <td class="table-plus"><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($g->nama_guru); ?></td>
                                            <td><?php echo e($g->periode); ?></td>
                                            <td><?php echo e($g->jam); ?></td>
                                            <td><?php echo e(number_format($g->nominal)); ?></td>
                                            <td><?php echo e($g->tanggal); ?></td>
                                            <td><?php echo e($g->waktu); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\project_skripsi\kodingan\sistem_informasi_managemnt_keuangan\sim-laravel\resources\views/halaman_bendahara/laporan/detail.blade.php ENDPATH**/ ?>