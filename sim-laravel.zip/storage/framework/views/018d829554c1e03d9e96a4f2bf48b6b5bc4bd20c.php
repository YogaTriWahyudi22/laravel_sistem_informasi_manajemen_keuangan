

<?php $__env->startSection('content'); ?>
    <div class="main-container">
        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="page-header">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="title">
                                <h4>Kelola Jurusan / Tambah Data</h4>
                            </div>
                            <nav aria-label="breadcrumb" role="navigation">
                            </nav>
                        </div>
                    </div>
                </div>
                <div class="pd-20 card-box mb-30">
                    <form action="<?php echo e(route('jurusan_tambah')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label class="col-sm-12 col-md-2 col-form-label">Nama Jurusan</label>
                            <div class="col-sm-12 col-md-10">
                                <input class="form-control" type="text" name="nama_jurusan" placeholder="Input Jurusan"
                                    required>
                            </div>
                        </div>
                        <button class="btn btn-primary" type="submit">Submit</button>
                        <a href="<?php echo e(route('jurusan')); ?>" class="btn btn-danger">Kembali</a>
                    </form>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\project_skripsi\kodingan\sistem_informasi_managemnt_keuangan\sim-laravel\resources\views/halaman_admin/kelola_jurusan/tambah.blade.php ENDPATH**/ ?>