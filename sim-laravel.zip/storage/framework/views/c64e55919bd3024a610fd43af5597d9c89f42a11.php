<div class="left-side-bar">
    <div class="brand-logo">
        <a href="index.html">
            <img src="<?php echo e(asset('gambar/logo2.png')); ?>" alt="" width="80rem" class="light-logo ml-5">
            
        </a>
        <div class="close-sidebar" data-toggle="left-sidebar-close">
            <i class="ion-close-round"></i>
        </div>
    </div>
    <div class="menu-block customscroll">
        <div class="sidebar-menu">
            <ul id="accordion-menu">
                <?php if(Auth::user()->status == 'admin'): ?>
                    <li>
                        <a href="<?php echo e(route('dashboard')); ?>" class="dropdown-toggle no-arrow">
                            <span class="micon icon-copy fa fa-dashboard ml-1"></span><span
                                class="mtext">Dashboard</span>
                        </a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('kelola_akun')); ?>" class="dropdown-toggle no-arrow">
                            <span class="micon icon-copy fa fa-user-plus ml-1"></span><span
                                class="mtext">Kelola
                                Akun</span>
                        </a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('siswa')); ?>" class="dropdown-toggle no-arrow">
                            <span class="micon icon-copy fa fa-users"></span><span class="mtext">Input Data
                                Siswa</span>
                        </a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('guru')); ?>" class="dropdown-toggle no-arrow">
                            <span class="micon icon-copy fa fa-users"></span><span class="mtext">Input Data
                                Guru</span>
                        </a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('kelas')); ?>" class="dropdown-toggle no-arrow">
                            <span class="micon fa fa-building-o"></span><span class="mtext">Input Data
                                Kelas</span>
                        </a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('jurusan')); ?>" class="dropdown-toggle no-arrow">
                            <span class="micon fa fa-address-book"></span><span class="mtext">Input Data
                                Jurusan</span>
                        </a>
                    </li>
                <?php elseif(Auth::user()->status == 'bendahara'): ?>

                    <li>
                        <a href="<?php echo e(route('dashboard')); ?>" class="dropdown-toggle no-arrow">
                            <span class="micon icon-copy fa fa-dashboard ml-1"></span><span
                                class="mtext">Dashboard</span>
                        </a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('pembayaran')); ?>" class="dropdown-toggle no-arrow">
                            <span class="micon icon-copy fa fa-money ml-1"></span><span class="mtext">Kelola
                                Pembayaran</span>
                        </a>
                    </li>

                    <li class="dropdown">
                        <a href="javascript:;" class="dropdown-toggle">
                            <span class="micon icon-copy fa fa-level-down"></span><span class="mtext"> Kas
                                Masuk</span>
                        </a>
                        <ul class="submenu">
                            <li><a href="<?php echo e(route('pendaftaran')); ?>">Pendaftaran</a></li>
                            <li><a href="<?php echo e(route('uang_seragam')); ?>">Uang Seragam</a></li>
                            <li><a href="<?php echo e(route('uang_spp')); ?>">Uang SPP</a></li>
                            <li><a href="<?php echo e(route('dsp')); ?>">Uang DSP</a></li>
                            <li><a href="<?php echo e(route('pkl')); ?>">Uang PKL</a></li>
                            <li><a href="<?php echo e(route('uang_ujian')); ?>">Uang Ujian</a></li>
                        </ul>
                    </li>

                    <li class="dropdown">
                        <a href="javascript:;" class="dropdown-toggle">
                            <span class="micon icon-copy fa fa-level-up"></span><span class="mtext"> Kas
                                Keluar</span>
                        </a>
                        <ul class="submenu">
                            <li><a href="<?php echo e(route('pembayaran_gaji')); ?>">Pembayaran Gaji</a></li>
                            <li><a href="<?php echo e(route('pembayaran_lain')); ?>">pengeluaran Laninya</a></li>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\project_skripsi\kodingan\sistem_informasi_managemnt_keuangan\sim-laravel\resources\views/pembagian_template/sidebar.blade.php ENDPATH**/ ?>