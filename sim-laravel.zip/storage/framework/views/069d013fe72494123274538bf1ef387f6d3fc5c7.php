<!DOCTYPE html>
<html>

<head>
    <?php echo $__env->make('pembagian_template.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <div class="login-page">
        <div class="login-header box-shadow">
            <div class="container">
                <div class="container-fluid d-flex justify-content-between align-items-center">
                    <div class="brand-logo">
                        <a href="<?php echo e(url('/')); ?>">
                            <img src="<?php echo e(asset('gambar/logo2.png')); ?>" width="70rem" alt="">
                        </a>
                    </div>
                    <div class="login-menu">
                        <ul>
                            <li><a href="<?php echo e(route('login')); ?>">Masuk</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <?php echo $__env->yieldContent('user'); ?>

    <?php echo $__env->make('pembagian_template.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH D:\xampp\htdocs\project_skripsi\kodingan\sistem_informasi_managemnt_keuangan\sim-laravel\resources\views/template/user.blade.php ENDPATH**/ ?>