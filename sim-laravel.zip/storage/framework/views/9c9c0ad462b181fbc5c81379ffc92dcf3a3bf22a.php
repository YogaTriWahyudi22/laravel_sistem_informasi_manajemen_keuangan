

<?php $__env->startSection('content'); ?>
    <div class="main-container">
        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="page-header">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="title">
                                <h4>Data Pembayaran Gaji Guru / Tambah Data</h4>
                            </div>
                            <nav aria-label="breadcrumb" role="navigation">
                            </nav>
                        </div>
                    </div>
                </div>
                <div class="pd-20 card-box mb-30">
                    <?php
                        $t = Date('Y');
                        $b = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
                    ?>
                    <form action="<?php echo e(route('pembayaran_gaji_tambah')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label class="control-label"> Pilih Bulan</label>
                            <select class="form-control" name="periode" aria-label="Default select example" required>
                                <option selected>Pilih Bulan</option>
                                <?php $__currentLoopData = $b; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?= $i . '-' . $t ?>"><?= $i . '-' . $t ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="control-label"> Pilih Guru</label>
                            <?php
                                $guru = DB::table('guru')->get();
                            ?>
                            <select class="form-control" name="id_guru" aria-label="Default select example" required>
                                <option selected>Pilih Guru</option>

                                <?php $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($i->id_guru); ?>"><?php echo e($i->nama_guru); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="control-label"> Jam Kerja</label>
                            <div><input type="text" name="jam" name="nominal" class="form-control" id="jam"></div>
                        </div>

                        <div class="form-group">
                            <label class="control-label"> Nominal</label>
                            <div>
                                <input type="text" readonly="" name="nominal" class="form-control" id="total">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary"><span class="text-capitalize">simpan</span></button>
                        <a href="<?php echo e(route('pembayaran_gaji')); ?>" class="btn btn-danger">Back</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            let jam = document.getElementById("jam")
            jam.addEventListener('keyup', function() {
                let total = "40000"
                document.getElementById("total").value = parseInt(total) * parseInt(this.value)
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\project_skripsi\kodingan\sistem_informasi_managemnt_keuangan\sim-laravel\resources\views/halaman_bendahara/gaji_guru/tambah.blade.php ENDPATH**/ ?>