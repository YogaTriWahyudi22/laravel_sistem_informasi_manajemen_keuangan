

<?php $__env->startSection('content'); ?>
    <div class="main-container">
        <div class="pd-ltr-20 xs-pd-20-10">
            <div class="min-height-200px">
                <div class="page-header">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="title">
                                <h4>Data Pembayaran Pendaftaran</h4>
                            </div>
                            <nav aria-label="breadcrumb" role="navigation">
                            </nav>
                        </div>
                    </div>
                </div>
                <div class="pd-20 bg-white border-radius-4 box-shadow mb-30">
                    <div class="pd-20">
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                            Tambah Data
                        </button>

                    </div>
                    

                    <?php echo $__env->make('halaman_bendahara.pendaftaran.tambah', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    
                    <div class="pb-20">
                        <table class="data-table table stripe hover nowrap">
                            <thead>
                                <tr class="text-center">
                                    <th class="table-plus datatable-nosort">Nomor</th>
                                    <th>Nama Siswa</th>
                                    <th>NIS</th>
                                    <th>Jurusan</th>
                                    <th>Jenis Kelamin</th>
                                    <th>Tanggal Lahir</th>
                                    <th>Wali Siswa</th>
                                    <th>Alamat Siswa</th>
                                    <th class="datatable-nosort">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $index; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $id = $i->id_draf;
                                    ?>
                                    <tr class="text center">
                                        <td class="table-plus"><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($i->nama_siswa); ?></td>
                                        <td><?php echo e($i->nis); ?></td>
                                        <td><?php echo e($i->nama_jurusan); ?></td>
                                        <td><?php echo e($i->jk); ?></td>
                                        <td><?php echo e($i->tanggal_lahir); ?></td>
                                        <td><?php echo e($i->wali_siswa); ?></td>
                                        <td><?php echo e($i->alamat_siswa); ?></td>
                                        <td>
                                            <div class="btn-group" role="group" aria-label="Basic example">
                                                <?php if($i->bayar == null): ?>

                                                    <a href="" class="btn btn-success" class="btn btn-primary" id="pilih"
                                                        onchange="kategori()" data-toggle="modal"
                                                        data-target="#modalsaya<?php echo e($i->id_draf); ?>"><span
                                                            class="text-capitalize">bayar</span></a>
                                                <?php else: ?>

                                                    <a href="" class="btn btn-success" class="btn btn-primary" id="kelas"
                                                        onchange="kelas()" data-toggle="modal"
                                                        data-target="#kelassaya<?php echo e($i->id_draf); ?>"><span
                                                            class="text-capitalize">kelas</span></a>
                                                <?php endif; ?>

                                                <a href="<?php echo e(route('pendaftaran_edit', $i->id_draf)); ?>"
                                                    class="btn btn-info mx-2"><i class="dw dw-edit2"></i>
                                                    Edit</a>
                                                <form action="<?php echo e(route('pendaftaran_hapus', $i->id_draf)); ?>"
                                                    method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <button class="btn btn-danger"><i class="dw dw-delete-3 mr-2"></i>
                                                        Delete</button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
    <?php $__currentLoopData = $index; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <!-- Modal -->
        <div class="modal fade" id="modalsaya<?php echo e($item->id_draf); ?>" tabindex="-1" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel"><span class="text-capitalize"> Pembayaran Uang
                                Pendaftaran</span></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('bayar', $item->id_draf)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <span><?php echo e($item->nama_siswa); ?></span>
                            <?php if(isset($pembayaran)): ?>
                                <input type="hidden" name="bayar" value="<?php echo e($pembayaran->nominal); ?>">
                                <p>Konfirmasi Pembayaran Uang pendaftaran Dengan Nama:
                                    <strong><?php echo e($item->nama_siswa); ?></strong>
                                    senilai Rp.<?php echo e(number_format($pembayaran->nominal)); ?>

                                </p>
                            <?php endif; ?>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><span
                                class="text-capitalize">tutup</span></button>
                        <button type="submit" class="btn btn-primary"><span class="text-capitalize">simpan</span></button>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php $__currentLoopData = $index; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <!-- Modal -->
        <div class="modal fade" id="kelassaya<?php echo e($kelas->id_draf); ?>" tabindex="-1" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel"><span class="text-capitalize"> Pilih Kelas</span>
                        </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <?php
                            $kelas_table = DB::table('kelas')->get();
                        ?>
                        <form action="<?php echo e(route('pendaftaran_siswa', $kelas->id_draf)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <select class="form-control" name="id_kelas" aria-label="Default select example" required>
                                <option selected>Pilih Kelas</option>
                                <?php $__currentLoopData = $kelas_table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($k->id_kelas); ?>"><?php echo e($k->kelas); ?> -- <?php echo e($k->nama_kelas); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <input type="hidden" name="id_jurusan" value="<?php echo e($kelas->id_jurusan); ?>">
                            <input type="hidden" name="nama_siswa" value="<?php echo e($kelas->nama_siswa); ?>">
                            <input type="hidden" name="nis" value="<?php echo e($kelas->nis); ?>">
                            <input type="hidden" name="jk" value="<?php echo e($kelas->jk); ?>">
                            <input type="hidden" name="tanggal_lahir" value="<?php echo e($kelas->tanggal_lahir); ?>">
                            <input type="hidden" name="wali_siswa" value="<?php echo e($kelas->wali_siswa); ?>">
                            <input type="hidden" name="alamat_siswa" value="<?php echo e($kelas->alamat_siswa); ?>">
                            <input type="hidden" name="status" value="<?php echo e($kelas->status); ?>">
                            <input type="hidden" name="bayar" value="<?php echo e($kelas->bayar); ?>">
                            <input type="hidden" name="tanggal" value="<?php echo e($kelas->tanggal); ?>">

                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal"><span
                                        class="text-capitalize">tutup</span></button>
                                <button type="submit" class="btn btn-primary"><span
                                        class="text-capitalize">simpan</span></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <script>
        function kategori() {
            var tes = document.getElementById("pilih").value;
            console.log(tes);
            $('#modalsaya' + tes).modal('show');

        }

        function kelas() {
            var kelass = document.getElementById("kelas").value;
            console.log(tes);
            $('#kelassaya' + tes).modal('show');

        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\project_skripsi\kodingan\sistem_informasi_managemnt_keuangan\sim-laravel\resources\views/halaman_bendahara/pendaftaran/index.blade.php ENDPATH**/ ?>