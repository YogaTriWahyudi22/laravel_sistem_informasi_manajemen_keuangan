@extends('template.user')

@section('user')

    <div class="login-wrap d-flex align-items-center flex-wrap justify-content-center">
        {{-- <div class="container"> --}}
        <div class="row align-items-center">
            <div class="col-md-12 col-lg-12">
                <center>
                    <h3 style="color: #455a64">Sistem Informasi Administrasi Keuangan <br> SMK Cendana Padang
                        Panjang
                    </h3>
                    <img src="{{ asset('vendors/images/login-page-img.png') }}" alt="">
                </center>
            </div>
        </div>
    </div>

@endsection
