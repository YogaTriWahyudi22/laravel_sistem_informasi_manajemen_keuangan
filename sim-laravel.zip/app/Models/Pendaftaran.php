<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pendaftaran extends Model
{
    use HasFactory;

    protected $table = 'pendaftaran';

    protected $primaryKey = 'id_pendaftaran';

    protected $fillable = ['id_jurusan', 'nama_siswa', 'nis', 'jk', 'tanggal_lahir', 'wali_siswa', 'alamat_siswa', 'status', 'kelas', 'bayar', 'tanggal'];

    public $timestamps = false;
}
