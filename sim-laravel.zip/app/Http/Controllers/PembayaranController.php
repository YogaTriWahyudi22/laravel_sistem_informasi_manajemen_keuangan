<?php

namespace App\Http\Controllers;

use App\Models\Pembayaran;
use Illuminate\Http\Request;
use RealRashid\SweetAlert\Facades\Alert;

class PembayaranController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $index = Pembayaran::all();
        return view('halaman_bendahara.pembayaran.index', compact('index'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('halaman_bendahara.pembayaran.tambah');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $nominal = explode("Rp.", $request->nominal)[1];
        $nominal_baru = explode(".", $nominal);
        $nominal_jelas = (int) implode($nominal_baru);

        $tambah = new Pembayaran;
        $tambah->kode = $request->kode;
        $tambah->jenis_pembayaran = $request->jenis_pembayaran;
        $tambah->nominal = $nominal_jelas;
        $tambah->save();

        Alert::success('Data Berhasil', 'Data Berhasil Ditambah');
        return redirect()->route('pembayaran');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $edit = Pembayaran::where('id_pembayaran', $id)->first();
        return view('halaman_bendahara.pembayaran.edit', compact('edit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $update = Pembayaran::where('id_pembayaran', $id)->first();
        $update->kode = $request->kode;
        $update->jenis_pembayaran = $request->jenis_pembayaran;
        $update->nominal = $request->nominal;
        $update->save();

        Alert::success('Data Berhasil', 'Data Berhasil Diupdate');
        return redirect()->route('pembayaran');
    }


    public function destroy($id)
    {
        $delete = Pembayaran::where('id_pembayaran', $id)->first();
        $delete->delete();
        Alert::error('Data Berhasil', 'Data Berhasil Dihapus');
        return redirect()->route('pembayaran');
    }
}
